﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Calculator
{
    struct variable   //不可被继承，构造无参函数不可被重载，可在在其中定义方法
    {
        public int x;
        public int y;
    }
    class Program
    {
        static void Main(string[] args)
        {
            Calculator cal = new Calculator();
            SubtractionString sub = new SubtractionString();
            AddString add = new AddString();
           

            cal.Operation();

        
        }
    }

    class Calculator
    {
        char sym;
        char symbol;
        variable var;
        public void Operation()
        {
            do
            {
                sym = char.Parse(Console.ReadLine());    
                symbol = char.Parse(Console.ReadLine());
                
                   switch (symbol)
                   {
                       case '+': if (sym == 'i')
                           { 
                               var.x = Convert.ToInt32(Console.ReadLine());
                               var.y = Convert.ToInt32(Console.ReadLine());
                               Console.WriteLine("{0}+{1}={2}", var.x, var.y, (var.x + var.y));
                           }
                           else if (sym == 's')
                           {
                               AddString AS = new AddString();
                           
                               AS.Str1 = Convert.ToString(Console.ReadLine());
                               AS.Str2 = Convert.ToString(Console.ReadLine());
                               AS.addStr();
                           }
                           break;
                       case '-':
                           if (sym == 'i')
                           {
                               var.x = Convert.ToInt32(Console.ReadLine());
                               var.y = Convert.ToInt32(Console.ReadLine());
                               Console.WriteLine("{0}-{1}={2}", var.x, var.y, (var.x - var.y));
                           }
                           else if(sym=='s')
                           {
                               SubtractionString SUB = new SubtractionString();
                               SUB.Str1 = Convert.ToString(Console.ReadLine());
                               SUB.Str2 = Convert.ToString(Console.ReadLine());
                               SUB.Subtraction();
                           }
                           break;
                       case '*':
                           if (sym == 'i')
                           {
                               var.x = Convert.ToInt32(Console.ReadLine());
                               var.y = Convert.ToInt32(Console.ReadLine());
                               Console.WriteLine("{0}*{1}={2}", var.x, var.y, (var.x * var.y));
                           }
                           break;
                       case '/':
                           if (sym == 'i')
                           {
                               var.x = Convert.ToInt32(Console.ReadLine());
                               var.y = Convert.ToInt32(Console.ReadLine());
                               Console.WriteLine("{0}/{1}={2}", var.x, var.y, (var.x / var.y));
                           }
                           //捕获异常*/
                           try
                           {
                               //包含容易出现异常的代码
                               Console.WriteLine(var.x / var.y);
                           }
                           //catch（异常类，异常实例对象）
                           catch (Exception ex)
                           {
                               //异常处理代码
                               Console.WriteLine("Output Errors:" + ex.Message);
                               //Console.WriteLine("分母不可为0！");
                           }
                           finally
                           {
                               Console.WriteLine("结束");
                           }
                           break;
                       default: Console.WriteLine("运算符号输入错误！");
                           break;     //default 后的 break 不可省略
                   }  //switch 结束
                   if (sym == 'i')
                   {
                       Equal eq = new Equal();
                       eq.Equals(var.x, var.y);
                   }
              }while(true);  
         
        }
    }
}
